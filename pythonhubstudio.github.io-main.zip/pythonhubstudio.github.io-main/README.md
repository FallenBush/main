# pythonhubstudio.github.io
Из видео урока на YT канале Python Hub Studio
